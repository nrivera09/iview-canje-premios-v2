import React from 'react';

const NoTournaments = () => {
  return <div>NoTournaments</div>;
};

export default NoTournaments;
