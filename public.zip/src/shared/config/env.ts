export const ENV = {
  API_BASE_URL: 'https://dev-api-iview.acity.com.pe/api/',
  API_BASE_URL_V1: 'https://dev-api-canje-regalo.acity.com.pe/api/',
  REACT_APP_ACITY_SOCKET: 'https://dev-api-canje-regalo.acity.com.pe/',
  API_IMG64: 'https://lab-api-assets-iview.acity.com.pe/',
};
