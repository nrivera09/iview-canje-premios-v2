interface Window {
  handleCloseClick?: () => void;
}
