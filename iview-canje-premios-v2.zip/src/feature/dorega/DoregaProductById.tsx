import React, { FC } from 'react';

interface DoregaProductByIdProps {
  id: string;
}
const DoregaProductById: FC<DoregaProductByIdProps> = ({ id }) => {
  return <div>DoregaProductById</div>;
};

export default DoregaProductById;
