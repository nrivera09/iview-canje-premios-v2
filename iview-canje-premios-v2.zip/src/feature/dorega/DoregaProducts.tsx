import React from 'react';

const DoregaProducts = () => {
  return <div>DoregaProducts</div>;
};

export default DoregaProducts;
