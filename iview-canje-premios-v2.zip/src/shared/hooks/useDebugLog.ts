// src/shared/hooks/useDebugLog.ts

import { useState, useCallback } from 'react';

export type DebugLogType = 'info' | 'error' | 'warning';

export interface DebugLog {
  timestamp: Date;
  message: string;
  type: DebugLogType;
}

export const useDebugLog = () => {
  const [logs, setLogs] = useState<DebugLog[]>([]);

  const addLog = useCallback((message: string, type: DebugLogType = 'info') => {
    setLogs((prev) => [...prev, { message, type, timestamp: new Date() }]);
  }, []);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  return { logs, addLog, clearLogs };
};
