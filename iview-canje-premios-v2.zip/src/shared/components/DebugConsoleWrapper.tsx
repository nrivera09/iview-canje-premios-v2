// src/shared/debug/DebugConsoleWrapper.tsx

import React, { useEffect } from 'react';
import { DebugConsole } from './DebugConsole';
import { DebugBridge } from '../debug/DebugBridge';
import { ConsoleInterceptor } from '../debug/ConsoleInterceptor';
import { ErrorCatcher } from '../debug/ErrorCatcher';
export const DebugConsoleWrapper: React.FC = () => {
  useEffect(() => {
    DebugBridge.init();
    ConsoleInterceptor.init();
    ErrorCatcher.init();
  }, []);

  return <DebugConsole />;
};
