// src/shared/debug/DebugConsole.tsx

import React, { useEffect, useRef } from 'react';
import { useDebugStore } from '@/store/debugStore';

export const DebugConsole: React.FC = () => {
  const logs = useDebugStore((state) => state.logs);
  const clearLogs = useDebugStore((state) => state.clearLogs);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Auto scroll al último log cada vez que se agrega uno
    containerRef.current?.scrollTo(0, containerRef.current.scrollHeight);
  }, [logs]);

  return (
    <div
      style={{
        position: 'fixed',
        bottom: 0,
        wordWrap: 'break-word',
        left: 0,
        width: '100%',
        maxHeight: '200px',
        overflowY: 'auto',
        backgroundColor: '#000',
        color: '#00FF00',
        fontFamily: 'monospace',
        fontSize: '12px',
        padding: '10px',
        zIndex: 9999,
        boxShadow: '0px -2px 8px rgba(0, 255, 0, 0.3)',
      }}
      ref={containerRef}
    >
      <div
        style={{
          marginBottom: '5px',
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <span>--- Debug Console ---</span>
        <button
          style={{
            marginLeft: '10px',
            backgroundColor: '#333',
            color: '#0f0',
            border: '1px solid #0f0',
            padding: '2px 5px',
            cursor: 'pointer',
          }}
          onClick={clearLogs}
        >
          Clear
        </button>
      </div>

      {logs.map((log, index) => (
        <div key={index}>
          [{log.timestamp.toLocaleTimeString()}] {log.type.toUpperCase()}:{' '}
          {log.message}
        </div>
      ))}
    </div>
  );
};
