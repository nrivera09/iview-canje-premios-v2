export type SoundEffectType = 'pin' | 'error' | 'button';
