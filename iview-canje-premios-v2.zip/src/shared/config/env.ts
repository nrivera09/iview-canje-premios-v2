export const ENV = {
  API_BASE_URL: 'https://dev-api-iview.acity.com.pe/api/',
};
