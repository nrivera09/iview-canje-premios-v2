// src/shared/debug/DebugConsole.tsx

import React, { useEffect, useRef } from 'react';
import { useDebugStore } from '@/store/debugStore';

export const DebugConsole: React.FC = () => {
  const logs = useDebugStore((state: { logs: any }) => state.logs);
  const clearLogs = useDebugStore(
    (state: { clearLogs: any }) => state.clearLogs
  );
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    containerRef.current?.scrollTo(0, containerRef.current.scrollHeight);
  }, [logs]);

  return <></>;
};
