import { DebugBridge } from './DebugBridge';
import { ConsoleInterceptor } from './ConsoleInterceptor';
import { ErrorCatcher } from './ErrorCatcher';

export const initializeDebug = () => {
  DebugBridge.init();
  ConsoleInterceptor.init();
  ErrorCatcher.init();
};
