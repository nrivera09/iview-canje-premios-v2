// src/shared/debug/ConsoleInterceptor.ts

import { useDebugStore } from '@/store/debugStore';

export class ConsoleInterceptor {
  static init() {
    const addLog = useDebugStore.getState().addLog;

    const originalLog = console.log;
    const originalWarn = console.warn;
    const originalError = console.error;

    console.log = (...args: any[]) => {
      addLog(args.map((arg) => JSON.stringify(arg)).join(' '), 'info');
      originalLog.apply(console, args);
    };

    console.warn = (...args: any[]) => {
      addLog(args.map((arg) => JSON.stringify(arg)).join(' '), 'warning');
      originalWarn.apply(console, args);
    };

    console.error = (...args: any[]) => {
      addLog(args.map((arg) => JSON.stringify(arg)).join(' '), 'error');
      originalError.apply(console, args);
    };
  }
}
