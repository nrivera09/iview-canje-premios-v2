// src/shared/debug/ErrorCatcher.ts

import { useDebugStore } from '@/store/debugStore';

export class ErrorCatcher {
  static init() {
    const addLog = useDebugStore.getState().addLog;

    window.onerror = (message, source, lineno, colno, error) => {
      addLog(`Error: ${message} at ${source}:${lineno}:${colno}`, 'error');
    };

    window.onunhandledrejection = (event) => {
      addLog(`Unhandled Promise Rejection: ${event.reason}`, 'error');
    };
  }
}
