import { useDebugStore } from '@/store/debugStore';

export class ActionLogger {
  static log(action: string) {
    const addLog = useDebugStore.getState().addLog;
    addLog(`[ACTION] ${action}`, 'info');
  }
}
