// src/shared/debug/DebugBridge.ts

import { DebugLogType } from '@/store/debugStore';
import { useDebugStore } from '@/store/debugStore';

export class DebugBridge {
  static init() {
    const addLog = useDebugStore.getState().addLog;
    const originalPostMessage: typeof window.postMessage =
      window.parent.postMessage.bind(window.parent);

    window.parent.postMessage = ((
      ...args: Parameters<typeof window.postMessage>
    ): void => {
      const [message] = args;
      addLog(`[SEND] ${JSON.stringify(message)}`);
      originalPostMessage(...args);
    }) as typeof window.postMessage;

    window.addEventListener('message', (event) => {
      addLog(`[RECEIVE] ${JSON.stringify(event.data)}`);
    });
  }
}
